import { useState } from 'react';
import Icon from '@/components/ui/icon';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import SmartImage from '@/components/ui/smart-image';

const MORNING_PHOTOS = [
  'https://icebergvideo.ru/photos/78605d5a-017a-493c-8e89-a29b0156e515.jpg',
  'https://icebergvideo.ru/photos/57149828-9037-474c-9006-015e3c9bbe94.jpg',
  'https://icebergvideo.ru/photos/783cb811-6ca8-49af-9199-309c8b819d19.jpg',
  'https://icebergvideo.ru/photos/5fe0ffc4-0fb7-4a24-81ab-8d9b270ad22b.jpg',
  'https://icebergvideo.ru/photos/2f7675e4-a636-41b1-832a-7b057084b52c.jpg',
  'https://icebergvideo.ru/photos/b32878cc-4ffc-4ac6-a89a-f2729b6a13cb.jpg',
  'https://icebergvideo.ru/photos/eaa2fd64-06b8-4a5a-9063-63b971b4bd90.jpg',
  'https://icebergvideo.ru/photos/5c1a943e-886b-421f-9863-a478c9b459c4.jpg',
  'https://icebergvideo.ru/photos/d0a06bbe-480e-45b0-8ac4-323cfc5f20a0.jpg',
  'https://icebergvideo.ru/photos/da9b97da-41e9-45cd-ab9a-072b26bd1b6c.jpg',
];

const CEREMONY_PHOTOS = [
  'https://icebergvideo.ru/photos/03f75063-60d5-41f5-962f-fc33ac00474c.jpg',
  'https://icebergvideo.ru/photos/9884e07a-6209-4cf3-9f6c-23c65b14c1b1.jpg',
  'https://icebergvideo.ru/photos/890ca427-c024-4601-89e5-ac12fdab8d44.jpg',
  'https://icebergvideo.ru/photos/1dab03cd-63df-4458-b889-1f420cd93b06.jpg',
  'https://icebergvideo.ru/photos/146a4e88-4d08-4881-98e1-cfe58e4a0cad.jpg',
  'https://icebergvideo.ru/photos/396ad2ba-aa54-4c8f-9ac1-3e3d503b321f.jpg',
  'https://icebergvideo.ru/photos/c43e81b2-43c6-488a-b242-ae82ef1f7293.jpg',
  'https://icebergvideo.ru/photos/35945ad1-a763-4057-83c8-e85508384484.jpg',
  'https://icebergvideo.ru/photos/84adfcf0-b6f4-409f-874f-3208741cac1f.jpg',
  'https://icebergvideo.ru/photos/24a39201-ec09-4f0c-8b94-1b0ec527b1b3.jpg',
];

const REPORTAGE_PHOTOS = [
  'https://icebergvideo.ru/photos/d31e63bd-6ca4-4428-ae39-7331d9c2f270.jpg',
  'https://icebergvideo.ru/photos/b958a2cd-fd97-4cb6-a184-cb815bd5e528.jpg',
  'https://icebergvideo.ru/photos/9fa695cb-8860-42a7-8a7e-dc0bede10bfc.jpg',
  'https://icebergvideo.ru/photos/e80d2e6c-9c48-429d-ab34-2682510dcff0.jpg',
  'https://icebergvideo.ru/photos/5a33b94b-ab10-42e9-9039-e6ae76cd89ae.jpg',
  'https://icebergvideo.ru/photos/ff5a01d7-b0d8-4587-9338-013694593bd7.jpg',
  'https://icebergvideo.ru/photos/81c50227-7d9e-4980-9a03-59c6ceb890e3.jpg',
  'https://icebergvideo.ru/photos/2e6cd7dc-bf92-41db-8c57-33b3bb5ca031.jpg',
  'https://icebergvideo.ru/photos/b9aa4109-b109-42ab-843e-9e6bad281639.jpg',
  'https://icebergvideo.ru/photos/8813e902-1c91-47e5-a38d-c21f29770583.jpg',
];

const TOMSK_PHOTOS = [
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/d61653f8-d7ef-45aa-84cd-a89b2b0609cf.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/1afc7915-f0cd-4387-b688-ffd7fedbc184.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/e653c0de-137d-4908-afbd-dde1783f6639.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/886aaf76-2264-4e96-b1a9-00e70eadd878.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/307028d3-1cce-4236-834f-ea8cad836952.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/38ce299c-9240-42b0-922f-bda90924b671.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/e8878c10-6757-4206-88ec-b4168c695982.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/6eac6394-0700-4fce-a684-a79e03a191e1.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/aa31b104-b769-4639-ba91-689e39bb343b.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/5e88b86f-1047-49f3-933d-e5708fe37739.jpg',
];

const WINTER_PHOTOS = [
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/7e35386d-d9f9-41f9-81a1-3237c25dbfba.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/12f2d934-6654-4c3c-81df-6593cffa5636.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/e92b7955-94c7-43e9-bf5b-32361bb2a833.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/241ff0d0-6129-4e62-b98e-f8179ad88819.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/7af0757f-d16c-440c-81f6-9e0d0b2cd1a5.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/77bfc620-8902-437b-ad48-a3c78fb81c96.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/cbe01a6e-6e35-4230-869b-cd4c8f6ae32d.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/e403f292-08af-48f4-a40b-ef1e6c0c89b8.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/0a2df4ce-9a61-41cb-9907-e8c4daf325ea.jpg',
  'https://cdn.poehali.dev/projects/c8c6bf73-a08e-42bc-96f2-0959e7bb7640/files/6020b279-b3ac-4d5c-8d46-5c4131fe6818.jpg',
];

type Item = {
  id: number;
  type: 'video' | 'photo';
  title: string;
  meta: string;
  img: string;
  gallery?: string[];
  video?: string;
  tabletOnly?: boolean;
  wide?: boolean;
};

const items: Item[] = [
  {
    id: 2,
    type: 'photo',
    title: 'Марина и Дмитрий',
    meta: 'Репортаж · 10 кадров',
    img: REPORTAGE_PHOTOS[0],
    gallery: REPORTAGE_PHOTOS,
  },
  {
    id: 4,
    type: 'photo',
    title: 'Утро невесты',
    meta: 'Фотосессия · 10 кадров',
    img: MORNING_PHOTOS[0],
    gallery: MORNING_PHOTOS,
  },
  {
    id: 6,
    type: 'photo',
    title: 'Церемония у воды',
    meta: 'Репортаж · 10 кадров',
    img: CEREMONY_PHOTOS[0],
    gallery: CEREMONY_PHOTOS,
  },
  {
    id: 7,
    type: 'photo',
    title: 'Прогулка по Томску',
    meta: 'Фотосессия · 10 кадров',
    img: TOMSK_PHOTOS[0],
    gallery: TOMSK_PHOTOS,
    tabletOnly: true,
  },
  {
    id: 8,
    type: 'photo',
    title: 'Зимний Томск',
    meta: 'Фотосессия · 10 кадров',
    img: WINTER_PHOTOS[0],
    gallery: WINTER_PHOTOS,
    wide: true,
    tabletOnly: true,
  },
];

const Portfolio = () => {
  const [active, setActive] = useState<Item | null>(null);
  const [slide, setSlide] = useState(0);

  const shown = items;

  const openItem = (item: Item) => {
    setActive(item);
    setSlide(0);
  };

  const nextSlide = () => {
    if (!active?.gallery) return;
    setSlide((s) => (s + 1) % active.gallery!.length);
  };

  const prevSlide = () => {
    if (!active?.gallery) return;
    setSlide((s) => (s - 1 + active.gallery!.length) % active.gallery!.length);
  };

  return (
    <section id="portfolio" className="py-8 bg-background">
      <div className="container">
        <div className="mb-10 text-center">
          <div className="font-display font-medium text-base tracking-[0.22em] uppercase text-primary mb-4">
            Портфолио
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {shown.map((item) => (
            <button
              key={item.id}
              onClick={() => openItem(item)}
              className={`group relative text-left overflow-hidden rounded-[1.5rem] border border-border bg-card animate-scale-in ${
                item.tabletOnly ? 'hidden sm:block lg:hidden' : ''
              } ${item.wide ? 'sm:col-span-2' : ''
              }`}
            >
              <div className={`overflow-hidden ${item.wide ? 'aspect-[4/5] sm:aspect-[16/9]' : 'aspect-[4/5]'}`}>
                <SmartImage
                  src={item.img}
                  alt={item.title}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-[#2E416F]/85 via-transparent to-transparent" />
              <div className="absolute top-4 left-4 inline-flex items-center gap-1.5 rounded-full bg-card/90 px-3 py-1.5 text-xs font-display font-semibold text-foreground">
                <Icon name={item.type === 'video' ? 'Play' : 'Camera'} size={13} />
                {item.type === 'video' ? 'Видео' : 'Фото'}
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-5 text-white">
                <div className="font-display font-bold text-lg">{item.title}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
        <DialogContent className="max-w-3xl p-0 overflow-hidden bg-card border-border">
          {active && (
            <div>
              <div className="relative bg-black">
                {active.video ? (
                  <video
                    src={active.video}
                    controls
                    autoPlay
                    className="w-full aspect-video bg-black"
                  />
                ) : (
                  <SmartImage
                    src={active.gallery ? active.gallery[slide] : active.img}
                    alt={active.title}
                    priority
                    className="w-full aspect-video object-contain bg-black"
                  />
                )}
                {active.gallery && (
                  <>
                    <button
                      onClick={prevSlide}
                      className="absolute left-3 top-1/2 -translate-y-1/2 inline-flex h-10 w-10 items-center justify-center rounded-full bg-card/80 text-foreground hover:bg-card transition-colors"
                      aria-label="Предыдущее фото"
                    >
                      <Icon name="ChevronLeft" size={20} />
                    </button>
                    <button
                      onClick={nextSlide}
                      className="absolute right-3 top-1/2 -translate-y-1/2 inline-flex h-10 w-10 items-center justify-center rounded-full bg-card/80 text-foreground hover:bg-card transition-colors"
                      aria-label="Следующее фото"
                    >
                      <Icon name="ChevronRight" size={20} />
                    </button>
                    <div className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-card/85 px-3 py-1 text-xs font-display font-semibold text-foreground">
                      {slide + 1} / {active.gallery.length}
                    </div>
                  </>
                )}
              </div>
              <div className="p-6">
                <div className="font-display font-bold text-2xl mb-1">{active.title}</div>
                <div className="text-muted-foreground">{active.meta}</div>
                {active.gallery && (
                  <div className="mt-4 grid grid-cols-5 gap-2">
                    {active.gallery.map((src, i) => (
                      <button
                        key={src}
                        onClick={() => setSlide(i)}
                        className={`aspect-square overflow-hidden rounded-lg border-2 transition-colors ${
                          i === slide ? 'border-primary' : 'border-transparent'
                        }`}
                      >
                        <SmartImage src={src} alt="" className="h-full w-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default Portfolio;