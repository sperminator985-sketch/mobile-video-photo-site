import { useEffect, useState } from 'react';
import Icon from '@/components/ui/icon';
import { Sheet, SheetContent, SheetTrigger, SheetClose } from '@/components/ui/sheet';
import CallbackDialog from './CallbackDialog';
import SmartImage from '@/components/ui/smart-image';

const LOGO = 'https://icebergvideo.ru/photos/14346e37-5113-4231-af71-69c04fab1812.png';

const desktopLinks = [
  { href: '#top', label: 'Главная', external: false },
  { href: '#about', label: 'О нас', external: false },
  { href: '#portfolio', label: 'Работы', external: false },
  { href: '#packages', label: 'Цены', external: false },
  { href: '#contacts', label: 'Контакты', external: false },
  { href: 'https://icebergvideo-old.ru', label: 'Old_Ver.', external: true },
  { href: 'http://www.icebergvideo-retro.ru', label: 'Retro_Ver.', external: true },
  { href: 'https://chat-tom.ru', label: 'Чат-Общага', external: true },
];

const mobileLinks = [
  { href: '#top', label: 'Главная', icon: 'Home', external: false },
  { href: '#about', label: 'О нас', icon: 'Users', external: false },
  { href: '#portfolio', label: 'Работы', icon: 'Film', external: false },
  { href: '#packages', label: 'Цены', icon: 'Wallet', external: false },
  { href: '#contacts', label: 'Контакты', icon: 'MapPin', external: false },
  { href: 'https://icebergvideo-old.ru', label: 'Old_Ver.', icon: 'History', external: true },
  { href: 'http://www.icebergvideo-retro.ru', label: 'Retro_Ver.', icon: 'Monitor', external: true },
  { href: 'https://chat-tom.ru', label: 'Чат-Общага', icon: 'MessageCircle', external: true },
];

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-card/85 backdrop-blur-md shadow-[0_8px_30px_-18px_rgba(46,65,111,0.5)]' : 'bg-transparent'
      }`}
    >
      <div className="container relative flex items-center justify-between h-[72px] md:h-[80px] xl:h-auto xl:flex-col xl:justify-start xl:gap-2 xl:py-3 gap-2">
        <a href="#top" className="flex items-center gap-2 sm:gap-3 min-w-0 shrink absolute left-1/2 -translate-x-1/2 xl:static xl:translate-x-0">
          <SmartImage src={LOGO} alt="" priority className="absolute right-full mr-2 sm:mr-3 md:static md:mr-0 h-8 sm:h-9 md:h-12 xl:h-[60px] w-auto shrink-0" />
          <SmartImage
            src="/assets/iceberg-video-logo-text.png"
            alt="Айсберг-видео"
            priority
            className="h-7 sm:h-8 md:h-11 xl:h-[50px] w-auto shrink-0"
          />
        </a>

        <nav className="hidden xl:flex items-center gap-1 whitespace-nowrap">
          {desktopLinks.map((l) => (
            <a
              key={l.href}
              href={l.href}
              {...(l.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
              className="rounded-full px-4 py-2 text-sm font-medium bg-primary text-primary-foreground -translate-y-0.5 shadow-md"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <Sheet>
          <SheetTrigger className="md:hidden ml-auto inline-flex items-center justify-center h-11 w-11 rounded-full bg-card/80 text-foreground shrink-0">
            <Icon name="Menu" size={22} />
          </SheetTrigger>
          <SheetContent side="right" className="w-[80%] bg-card border-border">
            <div className="mt-8 flex flex-col gap-0.5">
              {mobileLinks.map((l) => (
                <SheetClose asChild key={l.href}>
                  <a
                    href={l.href}
                    {...(l.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                    className="flex items-center gap-3 rounded-2xl px-4 py-2 text-lg font-display font-medium text-foreground hover:bg-secondary transition-colors"
                  >
                    <Icon name={l.icon} size={18} className="shrink-0 text-primary" />
                    {l.label}
                  </a>
                </SheetClose>
              ))}
              <CallbackDialog
                trigger={
                  <button className="w-full inline-flex items-center justify-center gap-2 rounded-full border border-primary/40 mt-2 px-5 py-3 text-base font-display font-medium text-primary">
                    <Icon name="PhoneCall" size={18} />
                    Заказать звонок
                  </button>
                }
              />
            </div>
          </SheetContent>
        </Sheet>
      </div>

      <nav className="hidden md:flex xl:hidden container justify-center items-center gap-0.5 pb-2 -mt-1 whitespace-nowrap">
        {desktopLinks.map((l) => (
          <a
            key={l.href}
            href={l.href}
            {...(l.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
            className="rounded-full px-3 py-2 text-[15px] font-medium bg-primary text-primary-foreground"
          >
            {l.label}
          </a>
        ))}
      </nav>
    </header>
  );
};

export default Header;